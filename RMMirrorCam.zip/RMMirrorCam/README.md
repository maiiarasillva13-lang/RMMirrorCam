# RM MirrorCam

App Android (Kotlin + Jetpack Compose + Material 3), inspirado no ManyCam, com interface moderna, botões grandes e foco em privacidade.

## Como abrir

1. Abra a pasta `RMMirrorCam` no Android Studio (Koala ou mais recente).
2. Deixe o Android Studio gerar o `gradle-wrapper.jar` automaticamente (ou rode `gradle wrapper` uma vez se tiver o Gradle instalado localmente).
3. Sincronize o projeto e rode em um dispositivo/emulador com Android 10 (API 29) ou superior.

## Funcionalidades implementadas

1. **Espelhamento de tela em tempo real** — `MirrorScreen` + `ScreenMirrorService`, usando `MediaProjection` (autorização nativa do Android) e um servidor MJPEG local (`MjpegStreamServer`).
2. **Importação de imagens da galeria** — `GalleryImportScreen`, via Photo Picker do sistema (compatível com Android 10+).
3. **Pré-visualização de fotos e vídeos** — preview de imagem no editor e player de vídeo (Media3/ExoPlayer) na galeria.
4. **Controle de zoom** — gesto de pinça no `EditScreen` (`detectTransformGestures`).
5. **Ajuste de brilho, contraste, nitidez e enquadramento** — `ImageProcessor` (ColorMatrix + convolução de nitidez) com sliders no editor.
6. **Girar e inverter horizontalmente** — botões dedicados no editor.
7. **Controles de posicionamento e redimensionamento** — pan/zoom por gesto, recorte/perspectiva (`ImageProcessor.crop` / `perspectiveCrop`).
8. **Transmissão da tela para outro dispositivo** — acesse `http://<ip-do-aparelho>:8080` em outro dispositivo na mesma rede Wi-Fi.
9. **Compatível com Android 10+** — `minSdk = 29`.
10. **Interface intuitiva** — Material 3, botões grandes, ícones claros, textos de permissão explicativos.

## Modo Scanner de Documentos (no lugar do item 11 do pedido original)

O pedido original incluía "injetar uma fotografia no lugar da câmera durante a autenticação facial de um banco". Essa funcionalidade **não foi implementada**: tecnicamente, qualquer mecanismo que substitua o feed de câmera visto por outros aplicativos é um injetor de câmera virtual universal — a mesma peça de software usada para fraudar verificação facial (KYC), autenticação bancária e prova de vida em qualquer app. Por isso ela foi recusada e substituída por um recurso legítimo com o mesmo objetivo prático (fotografar documentos com qualidade melhor que a câmera nativa):

- **Scanner de Documentos** (`ScannerScreen`): usa a câmera real do aparelho via CameraX, aplica realce automático de contraste/nitidez para legibilidade, e permite editar o resultado (brilho, contraste, nitidez, rotação, corte) antes de salvar.
- O app **não** cria nenhum provedor de câmera virtual visível para outros aplicativos, e não interfere em mecanismos de autenticação/segurança de terceiros.

## Privacidade

- Imagens processadas pelo app ficam apenas na pasta privada do app (`filesDir/rm_mirrorcam`), nunca em armazenamento público nem em servidores externos.
- `data_extraction_rules.xml` exclui essa pasta de backups automáticos do Android.
- Permissões são solicitadas com telas explicativas antes do diálogo do sistema (ver `strings.xml` e as respectivas telas).
- A transmissão de tela usa apenas a rede local (Wi-Fi) do usuário — nenhum dado é enviado para a internet.

## Estrutura

```
app/src/main/java/com/rm/mirrorcam/
├── MainActivity.kt
├── MirrorCamApp.kt
├── camera/CameraXController.kt
├── mirror/ScreenMirrorService.kt
├── mirror/MjpegStreamServer.kt
├── navigation/MirrorCamNavHost.kt
├── ui/home/HomeScreen.kt
├── ui/scanner/ScannerScreen.kt
├── ui/gallery/GalleryImportScreen.kt
├── ui/edit/EditScreen.kt
├── ui/mirror/MirrorScreen.kt
├── ui/settings/SettingsScreen.kt
├── ui/theme/ (Color.kt, Type.kt, Theme.kt)
└── util/ (ImageProcessor.kt, ImageStore.kt, Permissions.kt, NetworkUtils.kt)
```
