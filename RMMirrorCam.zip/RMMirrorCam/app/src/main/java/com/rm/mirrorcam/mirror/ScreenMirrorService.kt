package com.rm.mirrorcam.mirror

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.rm.mirrorcam.MirrorCamApp
import com.rm.mirrorcam.R
import java.io.ByteArrayOutputStream

/**
 * Serviço de primeiro plano responsável por capturar a própria tela do
 * aparelho (via MediaProjection, autorizado explicitamente pelo usuário no
 * diálogo do sistema) e publicar os quadros no servidor MJPEG local, para
 * que outro dispositivo na mesma rede possa visualizá-los. Não acessa nem
 * substitui a câmera, e não interfere em nenhum outro aplicativo.
 */
class ScreenMirrorService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var server: MjpegStreamServer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (data != null) startMirroring(resultCode, data)
            }
            ACTION_STOP -> stopMirroring()
        }
        return START_NOT_STICKY
    }

    private fun startMirroring(resultCode: Int, data: Intent) {
        startForeground(NOTIFICATION_ID, buildNotification())

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, data)
        mediaProjection = projection

        val metrics = DisplayMetrics()
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        val mjpegServer = MjpegStreamServer(PORT)
        mjpegServer.start(NanoHttpDummySocketTimeout, false)
        server = mjpegServer

        reader.setOnImageAvailableListener({ imgReader ->
            val image = imgReader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * width

                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)

                val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                val out = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, 60, out)
                mjpegServer.publishFrame(out.toByteArray())

                bitmap.recycle()
                cropped.recycle()
            } finally {
                image.close()
            }
        }, null)

        virtualDisplay = projection.createVirtualDisplay(
            "RMMirrorCamDisplay",
            width, height, density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )
    }

    private fun stopMirroring() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        server?.stop()
        server = null
        mediaProjection?.stop()
        mediaProjection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopMirroring()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, ScreenMirrorService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, MirrorCamApp.MIRROR_CHANNEL_ID)
            .setContentTitle(getString(R.string.mirror_service_notification_title))
            .setContentText(getString(R.string.mirror_service_notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(0, getString(R.string.mirror_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.rm.mirrorcam.action.START_MIRROR"
        const val ACTION_STOP = "com.rm.mirrorcam.action.STOP_MIRROR"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val NOTIFICATION_ID = 1001
        const val PORT = 8080
        // Pequeno timeout de socket exigido pela assinatura do NanoHTTPD.start()
        const val NanoHttpDummySocketTimeout = 5000
    }
}
