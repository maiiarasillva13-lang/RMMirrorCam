package com.rm.mirrorcam.util

import android.Manifest
import android.os.Build

/**
 * Centraliza as permissões usadas pelo app e seus respectivos textos de
 * justificativa (rationale), para que cada solicitação seja feita de forma
 * transparente — explicando ao usuário por que ela é necessária antes de
 * abrir o diálogo do sistema.
 */
object Permissions {

    val CAMERA = Manifest.permission.CAMERA

    /** Permissões de mídia corretas para a versão do Android em execução. */
    val MEDIA: Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO
        )
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    val NOTIFICATIONS: String? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.POST_NOTIFICATIONS
        else null
}
