package com.rm.mirrorcam.mirror

import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicReference

/**
 * Servidor HTTP local (MJPEG over HTTP) que permite que outro dispositivo
 * na mesma rede Wi-Fi abra http://<ip-deste-aparelho>:8080/ no navegador e
 * veja a tela espelhada ao vivo. Não requer nenhuma conta nem envia dados
 * para a internet — tudo acontece dentro da rede local do usuário.
 */
class MjpegStreamServer(port: Int = 8080) : NanoHTTPD(port) {

    private val latestFrame = AtomicReference<ByteArray?>(null)
    private val boundary = "rmmirrorcam-frame-boundary"

    fun publishFrame(jpegBytes: ByteArray) {
        latestFrame.set(jpegBytes)
    }

    override fun serve(session: IHTTPSession): Response {
        if (session.uri == "/stream") {
            return newChunkedResponse(
                Response.Status.OK,
                "multipart/x-mixed-replace; boundary=$boundary",
                MjpegInputStream()
            )
        }

        // Página simples para abrir no navegador de outro dispositivo.
        val html = """
            <html>
              <head><title>RM MirrorCam</title></head>
              <body style="margin:0;background:#111;display:flex;align-items:center;justify-content:center;height:100vh;">
                <img src="/stream" style="max-width:100%;max-height:100%;" />
              </body>
            </html>
        """.trimIndent()
        return newFixedLengthResponse(Response.Status.OK, "text/html", html)
    }

    /** InputStream que entrega continuamente o quadro mais recente em formato multipart. */
    private inner class MjpegInputStream : java.io.InputStream() {
        private var buffer: ByteArray = ByteArray(0)
        private var position = 0

        private fun fillNextFrame() {
            var frame = latestFrame.get()
            while (frame == null) {
                Thread.sleep(30)
                frame = latestFrame.get()
            }
            val header = "--$boundary\r\nContent-Type: image/jpeg\r\nContent-Length: ${frame.size}\r\n\r\n"
            val footer = "\r\n"
            val out = ByteArrayOutputStream()
            out.write(header.toByteArray())
            out.write(frame)
            out.write(footer.toByteArray())
            buffer = out.toByteArray()
            position = 0
        }

        override fun read(): Int {
            if (position >= buffer.size) fillNextFrame()
            return if (position < buffer.size) buffer[position++].toInt() and 0xFF else -1
        }
    }
}
