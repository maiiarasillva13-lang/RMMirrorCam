package com.rm.mirrorcam.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min

/**
 * Operações de processamento de imagem usadas pelo editor e pelo modo
 * Scanner: brilho, contraste, nitidez, rotação, espelhamento e recorte
 * por quatro cantos (correção de perspectiva), tudo feito localmente no
 * dispositivo — nenhuma imagem é enviada para fora do app.
 */
object ImageProcessor {

    /**
     * Aplica brilho (-100..100), contraste (-100..100) e nitidez (0..100)
     * em uma única passada, retornando um novo bitmap.
     */
    fun applyAdjustments(
        src: Bitmap,
        brightness: Float,
        contrast: Float,
        sharpness: Float
    ): Bitmap {
        val colorAdjusted = applyBrightnessContrast(src, brightness, contrast)
        return if (sharpness > 0f) applySharpen(colorAdjusted, sharpness) else colorAdjusted
    }

    private fun applyBrightnessContrast(src: Bitmap, brightness: Float, contrast: Float): Bitmap {
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)

        // Contraste: fator exponencial suave, brilho: deslocamento aditivo.
        val c = (contrast / 100f) + 1f // 0..2
        val b = (brightness / 100f) * 255f // -255..255
        val translate = (-0.5f * c + 0.5f) * 255f + b

        val matrix = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, translate,
                0f, c, 0f, 0f, translate,
                0f, 0f, c, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrix)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return result
    }

    /**
     * Aplica um filtro de nitidez (unsharp mask simplificado) por convolução
     * 3x3, útil especialmente para realçar textos de documentos.
     */
    private fun applySharpen(src: Bitmap, amount: Float): Bitmap {
        val strength = (amount / 100f).coerceIn(0f, 1f)
        if (strength == 0f) return src

        val width = src.width
        val height = src.height
        val input = IntArray(width * height)
        src.getPixels(input, 0, width, 0, 0, width, height)
        val output = IntArray(width * height)

        // Kernel de nitidez interpolado entre identidade e realce.
        val center = 1f + 4f * strength
        val edge = -strength

        fun pixelAt(x: Int, y: Int): Int {
            val cx = x.coerceIn(0, width - 1)
            val cy = y.coerceIn(0, height - 1)
            return input[cy * width + cx]
        }

        fun channel(value: Int, shift: Int) = (value shr shift) and 0xFF

        for (y in 0 until height) {
            for (x in 0 until width) {
                val p = pixelAt(x, y)
                val up = pixelAt(x, y - 1)
                val down = pixelAt(x, y + 1)
                val left = pixelAt(x - 1, y)
                val right = pixelAt(x + 1, y)

                var r = 0f; var g = 0f; var b = 0f
                for ((px, factor) in listOf(p to center, up to edge, down to edge, left to edge, right to edge)) {
                    r += channel(px, 16) * factor
                    g += channel(px, 8) * factor
                    b += channel(px, 0) * factor
                }

                val outR = r.toInt().coerceIn(0, 255)
                val outG = g.toInt().coerceIn(0, 255)
                val outB = b.toInt().coerceIn(0, 255)
                val alpha = (p shr 24) and 0xFF

                output[y * width + x] = (alpha shl 24) or (outR shl 16) or (outG shl 8) or outB
            }
        }

        return Bitmap.createBitmap(output, width, height, Bitmap.Config.ARGB_8888)
    }

    /** Gira a imagem em graus (ex: 90, 180, 270). */
    fun rotate(src: Bitmap, degrees: Float): Bitmap {
        if (degrees == 0f) return src
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    /** Inverte horizontalmente (espelha) a imagem. */
    fun flipHorizontal(src: Bitmap): Bitmap {
        val matrix = Matrix().apply { preScale(-1f, 1f) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    /** Recorte simples por retângulo normalizado (0..1) — usado no enquadramento. */
    fun crop(src: Bitmap, leftPct: Float, topPct: Float, rightPct: Float, bottomPct: Float): Bitmap {
        val left = (leftPct * src.width).toInt().coerceIn(0, src.width - 1)
        val top = (topPct * src.height).toInt().coerceIn(0, src.height - 1)
        val right = (rightPct * src.width).toInt().coerceIn(left + 1, src.width)
        val bottom = (bottomPct * src.height).toInt().coerceIn(top + 1, src.height)
        return Bitmap.createBitmap(src, left, top, right - left, bottom - top)
    }

    /**
     * Correção de perspectiva a partir de quatro cantos escolhidos pelo
     * usuário (usado no modo Scanner para "endireitar" um documento
     * fotografado em ângulo), usando Matrix.setPolyToPoly — não depende
     * de bibliotecas externas de visão computacional.
     */
    fun perspectiveCrop(
        src: Bitmap,
        topLeft: Pair<Float, Float>,
        topRight: Pair<Float, Float>,
        bottomRight: Pair<Float, Float>,
        bottomLeft: Pair<Float, Float>,
        outputWidth: Int,
        outputHeight: Int
    ): Bitmap {
        val srcPoints = floatArrayOf(
            topLeft.first, topLeft.second,
            topRight.first, topRight.second,
            bottomRight.first, bottomRight.second,
            bottomLeft.first, bottomLeft.second
        )
        val dstPoints = floatArrayOf(
            0f, 0f,
            outputWidth.toFloat(), 0f,
            outputWidth.toFloat(), outputHeight.toFloat(),
            0f, outputHeight.toFloat()
        )

        val matrix = Matrix()
        matrix.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4)

        val result = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(src, matrix, paint)
        return result
    }

    fun scaleDownIfNeeded(src: Bitmap, maxDimension: Int = 2048): Bitmap {
        val largest = max(src.width, src.height)
        if (largest <= maxDimension) return src
        val scale = maxDimension.toFloat() / largest
        val newWidth = max(1, (src.width * scale).toInt())
        val newHeight = max(1, (src.height * scale).toInt())
        return Bitmap.createScaledBitmap(src, newWidth, newHeight, true)
    }
}
