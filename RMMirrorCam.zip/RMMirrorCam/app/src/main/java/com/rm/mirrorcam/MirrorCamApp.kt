package com.rm.mirrorcam

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/**
 * Application class. Cria o canal de notificação usado pelo serviço de
 * espelhamento de tela, exigido a partir do Android 8, e necessário para
 * que o usuário veja de forma transparente quando a transmissão está ativa.
 */
class MirrorCamApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                MIRROR_CHANNEL_ID,
                "Espelhamento de tela",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mostra quando o RM MirrorCam está transmitindo sua tela"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val MIRROR_CHANNEL_ID = "mirror_service_channel"
    }
}
