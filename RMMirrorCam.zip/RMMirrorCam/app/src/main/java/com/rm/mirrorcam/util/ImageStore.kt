package com.rm.mirrorcam.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/**
 * Lê e grava imagens exclusivamente na área privada do app
 * (filesDir/rm_mirrorcam), que não é acessível por outros aplicativos nem
 * incluída em backups (veja data_extraction_rules.xml). Isso garante que
 * fotos de documentos e edições do usuário permaneçam privadas no
 * dispositivo.
 */
object ImageStore {

    private const val DIR_NAME = "rm_mirrorcam"

    private fun storageDir(context: Context): File {
        val dir = File(context.filesDir, DIR_NAME)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun save(context: Context, bitmap: Bitmap, fileName: String = "img_${System.currentTimeMillis()}.jpg"): Uri {
        val file = File(storageDir(context), fileName)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun loadBitmap(context: Context, uri: Uri): Bitmap? {
        return context.contentResolver.openInputStream(uri)?.use { stream ->
            android.graphics.BitmapFactory.decodeStream(stream)
        }
    }
}
