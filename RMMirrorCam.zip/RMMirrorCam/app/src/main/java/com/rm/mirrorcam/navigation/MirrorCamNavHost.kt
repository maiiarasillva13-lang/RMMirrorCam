package com.rm.mirrorcam.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rm.mirrorcam.ui.edit.EditScreen
import com.rm.mirrorcam.ui.gallery.GalleryImportScreen
import com.rm.mirrorcam.ui.home.HomeScreen
import com.rm.mirrorcam.ui.mirror.MirrorScreen
import com.rm.mirrorcam.ui.scanner.ScannerScreen
import com.rm.mirrorcam.ui.settings.SettingsScreen

object Routes {
    const val HOME = "home"
    const val SCANNER = "scanner"
    const val GALLERY = "gallery"
    const val EDIT = "edit/{uri}"
    const val MIRROR = "mirror"
    const val SETTINGS = "settings"

    fun editRoute(encodedUri: String) = "edit/$encodedUri"
}

@Composable
fun MirrorCamNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenScanner = { navController.navigate(Routes.SCANNER) },
                onOpenGallery = { navController.navigate(Routes.GALLERY) },
                onOpenMirror = { navController.navigate(Routes.MIRROR) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.SCANNER) {
            ScannerScreen(
                onBack = { navController.popBackStack() },
                onCaptured = { encodedUri -> navController.navigate(Routes.editRoute(encodedUri)) }
            )
        }
        composable(Routes.GALLERY) {
            GalleryImportScreen(
                onBack = { navController.popBackStack() },
                onImageSelected = { encodedUri -> navController.navigate(Routes.editRoute(encodedUri)) }
            )
        }
        composable(Routes.EDIT) { backStackEntry ->
            val encodedUri = backStackEntry.arguments?.getString("uri") ?: ""
            EditScreen(encodedUri = encodedUri, onBack = { navController.popBackStack() })
        }
        composable(Routes.MIRROR) {
            MirrorScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
