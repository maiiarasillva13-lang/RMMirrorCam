package com.rm.mirrorcam.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkAddress
import java.net.Inet4Address

object NetworkUtils {
    /** Retorna o endereço IPv4 local do aparelho na rede Wi-Fi atual, se houver. */
    fun getLocalIpAddress(context: Context): String? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return null
        val linkProperties = cm.getLinkProperties(network) ?: return null
        val address = linkProperties.linkAddresses.firstOrNull { it.address is Inet4Address }
        return (address as LinkAddress?)?.address?.hostAddress
    }
}
