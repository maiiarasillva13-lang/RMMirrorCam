package com.rm.mirrorcam.ui.mirror

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Screenshot
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.rm.mirrorcam.mirror.ScreenMirrorService
import com.rm.mirrorcam.util.NetworkUtils

/**
 * Tela de controle do espelhamento de tela: solicita a autorização nativa
 * do Android (MediaProjection) de forma explícita — o próprio sistema
 * mostra ao usuário o aviso padrão de que a tela está sendo gravada/
 * transmitida enquanto o recurso estiver ativo — e mostra o endereço para
 * abrir em outro dispositivo da mesma rede Wi-Fi.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MirrorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var isMirroring by remember { mutableStateOf(false) }
    val localIp = remember { NetworkUtils.getLocalIpAddress(context) }

    val projectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(context, ScreenMirrorService::class.java).apply {
                action = ScreenMirrorService.ACTION_START
                putExtra(ScreenMirrorService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenMirrorService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, intent)
            isMirroring = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Espelhar tela") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Transmita a tela deste aparelho para outro dispositivo conectado " +
                    "à mesma rede Wi-Fi. O Android mostrará um aviso enquanto a " +
                    "transmissão estiver ativa.",
                style = MaterialTheme.typography.bodyLarge
            )

            if (!isMirroring) {
                Button(
                    onClick = {
                        val manager = context.getSystemService(MediaProjectionManager::class.java)
                        projectionLauncher.launch(manager.createScreenCaptureIntent())
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Screenshot, contentDescription = null)
                    Text("  Iniciar espelhamento", modifier = Modifier.padding(start = 8.dp))
                }
            } else {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Filled.Wifi, contentDescription = null)
                        Text(
                            text = "Em outro dispositivo na mesma rede, abra no navegador:",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            text = "http://${localIp ?: "endereço-indisponível"}:8080",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Button(
                    onClick = {
                        val intent = Intent(context, ScreenMirrorService::class.java).apply {
                            action = ScreenMirrorService.ACTION_STOP
                        }
                        context.startService(intent)
                        isMirroring = false
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.StopCircle, contentDescription = null)
                    Text("  Parar transmissão", modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
    }
}
