package com.rm.mirrorcam.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta Material 3 — tons roxo/azulado profissionais, com bom contraste
// para botões grandes e textos legíveis.
val Purple40 = Color(0xFF6750A4)
val PurpleGrey40 = Color(0xFF625B71)
val Tertiary40 = Color(0xFF7D5260)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Tertiary80 = Color(0xFFEFB8C8)

val SurfaceLight = Color(0xFFFFFBFE)
val SurfaceDark = Color(0xFF1C1B1F)

val AccentSuccess = Color(0xFF2E7D32)
val AccentWarning = Color(0xFFF9A825)
val AccentDanger = Color(0xFFD32F2F)
