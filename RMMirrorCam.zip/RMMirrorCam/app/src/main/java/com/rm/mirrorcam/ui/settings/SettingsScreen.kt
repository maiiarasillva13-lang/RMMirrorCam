package com.rm.mirrorcam.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ajustes e privacidade") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ListItem(
                headlineContent = { Text("Compatibilidade") },
                supportingContent = { Text("Android 10 (API 29) ou superior") }
            )
            ListItem(
                headlineContent = { Text("Armazenamento das imagens") },
                supportingContent = {
                    Text(
                        "Fotos e documentos processados pelo app ficam salvos apenas " +
                            "localmente, na pasta privada do RM MirrorCam, e não são " +
                            "enviados a nenhum servidor nem incluídos em backups automáticos."
                    )
                }
            )
            ListItem(
                headlineContent = { Text("Permissões") },
                supportingContent = {
                    Text(
                        "Câmera: captura no modo Scanner.\n" +
                            "Galeria: importar fotos e vídeos.\n" +
                            "Notificações: avisar quando o espelhamento de tela estiver ativo.\n" +
                            "Rede local: transmitir a tela para outro dispositivo na mesma Wi-Fi."
                    )
                }
            )
            ListItem(
                headlineContent = { Text("Sobre a transmissão de tela") },
                supportingContent = {
                    Text(
                        "O RM MirrorCam espelha apenas a tela do seu próprio aparelho para " +
                            "outro dispositivo que você escolher na sua rede. O app não " +
                            "interfere em mecanismos de segurança, autenticação ou " +
                            "verificação de identidade de outros aplicativos."
                    )
                }
            )
        }
    }
}
