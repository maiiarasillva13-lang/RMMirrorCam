package com.rm.mirrorcam.ui.scanner

import android.Manifest
import android.graphics.Bitmap
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import com.rm.mirrorcam.R
import com.rm.mirrorcam.camera.CameraXController
import com.rm.mirrorcam.util.ImageProcessor
import com.rm.mirrorcam.util.ImageStore
import kotlinx.coroutines.launch
import java.net.URLEncoder

/**
 * Modo Scanner de Documentos: usa a câmera real do aparelho (CameraX) para
 * capturar um documento e aplica realce de contraste/nitidez e correção de
 * perspectiva, tudo processado localmente dentro do próprio app. Esta tela
 * NÃO altera o que outros aplicativos recebem da câmera do sistema.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun ScannerScreen(onBack: () -> Unit, onCaptured: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val cameraPermission = rememberPermissionState(Manifest.permission.CAMERA)
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val cameraController = remember { CameraXController(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scanner de documentos") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                !cameraPermission.status.isGranted -> {
                    CameraPermissionRequest(
                        showRationale = cameraPermission.status.shouldShowRationale,
                        onRequest = { cameraPermission.launchPermissionRequest() }
                    )
                }
                capturedBitmap == null -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        AndroidView(
                            factory = { ctx ->
                                PreviewView(ctx).apply {
                                    scope.launch {
                                        cameraController.bindToLifecycle(lifecycleOwner, this@apply)
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        Icon(
                            imageVector = Icons.Filled.DocumentScanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(16.dp)
                        )
                    }
                    Button(
                        onClick = {
                            scope.launch {
                                val photo = cameraController.takePhoto()
                                // Realce automático pensado para documentos: mais
                                // contraste e nitidez para melhorar a legibilidade.
                                capturedBitmap = ImageProcessor.applyAdjustments(
                                    ImageProcessor.scaleDownIfNeeded(photo),
                                    brightness = 0f,
                                    contrast = 25f,
                                    sharpness = 40f
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Icon(Icons.Filled.PhotoCamera, contentDescription = null)
                        Text("  Capturar documento", modifier = Modifier.padding(start = 8.dp))
                    }
                }
                else -> {
                    val bmp = capturedBitmap!!
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Documento capturado",
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val uri = ImageStore.save(context, bmp)
                                val encoded = URLEncoder.encode(uri.toString(), "UTF-8")
                                onCaptured(encoded)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = null)
                            Text("  Usar esta captura e editar", modifier = Modifier.padding(start = 8.dp))
                        }
                        Button(
                            onClick = { capturedBitmap = null },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Tirar outra foto")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CameraPermissionRequest(showRationale: Boolean, onRequest: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Filled.DocumentScanner,
            contentDescription = null,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Text(
            text = if (showRationale)
                "Sem acesso à câmera não é possível escanear documentos."
            else
                stringResource(id = R.string.permission_camera_rationale),
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Button(onClick = onRequest) {
            Text(stringResource(id = R.string.permission_grant))
        }
    }
}

@Composable
private fun stringResource(id: Int) = androidx.compose.ui.res.stringResource(id = id)
