package com.rm.mirrorcam.ui.edit

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.rm.mirrorcam.util.ImageProcessor
import com.rm.mirrorcam.util.ImageStore
import kotlinx.coroutines.launch
import java.net.URLDecoder

/**
 * Editor de imagem: zoom (pinça), brilho, contraste, nitidez, rotação e
 * espelhamento horizontal, com salvamento apenas no armazenamento privado
 * do app (ImageStore). Funciona tanto para fotos vindas da galeria quanto
 * para capturas do modo Scanner.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(encodedUri: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val uri = remember(encodedUri) { Uri.parse(URLDecoder.decode(encodedUri, "UTF-8")) }

    val originalBitmap by produceState<Bitmap?>(initialValue = null, uri) {
        value = ImageStore.loadBitmap(context, uri)?.let { ImageProcessor.scaleDownIfNeeded(it) }
    }

    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var sharpness by remember { mutableFloatStateOf(0f) }
    var rotationDegrees by remember { mutableFloatStateOf(0f) }
    var flipped by remember { mutableStateOf(false) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var isSaving by remember { mutableStateOf(false) }

    val processedBitmap by produceState<Bitmap?>(
        initialValue = null,
        originalBitmap, brightness, contrast, sharpness, rotationDegrees, flipped
    ) {
        val base = originalBitmap
        if (base != null) {
            var bmp = ImageProcessor.applyAdjustments(base, brightness, contrast, sharpness)
            if (rotationDegrees != 0f) bmp = ImageProcessor.rotate(bmp, rotationDegrees)
            if (flipped) bmp = ImageProcessor.flipHorizontal(bmp)
            value = bmp
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editar imagem") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        brightness = 0f; contrast = 0f; sharpness = 0f
                        rotationDegrees = 0f; flipped = false
                        scale = 1f; offsetX = 0f; offsetY = 0f
                    }) {
                        Icon(Icons.Filled.Replay, contentDescription = "Restaurar")
                    }
                    IconButton(
                        enabled = processedBitmap != null && !isSaving,
                        onClick = {
                            val bmp = processedBitmap ?: return@IconButton
                            isSaving = true
                            scope.launch {
                                ImageStore.save(context, bmp)
                                isSaving = false
                                snackbarHostState.showSnackbar("Imagem salva com privacidade no app")
                            }
                        }
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(modifier = Modifier.padding(4.dp))
                        } else {
                            Icon(Icons.Filled.Save, contentDescription = "Salvar")
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offsetX += pan.x
                            offsetY += pan.y
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                processedBitmap?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Pré-visualização",
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            )
                    )
                } ?: CircularProgressIndicator()
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                LabeledSlider("Zoom", scale, 1f..5f) { scale = it }
                LabeledSlider("Brilho", brightness, -100f..100f) { brightness = it }
                LabeledSlider("Contraste", contrast, -100f..100f) { contrast = it }
                LabeledSlider("Nitidez", sharpness, 0f..100f) { sharpness = it }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(onClick = { rotationDegrees = (rotationDegrees + 90f) % 360f }) {
                        Icon(Icons.Filled.RotateRight, contentDescription = "Girar")
                    }
                    IconButton(onClick = { flipped = !flipped }) {
                        Icon(Icons.Filled.Flip, contentDescription = "Inverter horizontalmente")
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text("$label: ${value.toInt()}", style = MaterialTheme.typography.labelLarge)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
